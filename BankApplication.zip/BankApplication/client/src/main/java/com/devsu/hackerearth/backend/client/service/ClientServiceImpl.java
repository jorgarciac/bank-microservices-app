package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;

	public ClientServiceImpl(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}

	@Override
	public List<ClientDto> getAll() {
		// Get all clients
		return clientRepository.findAll().stream()
				.map(this::toDto)
				.collect(Collectors.toList());
	}

	@Override
	public ClientDto getById(Long id) {
		// Get clients by id
		return clientRepository.findById(id)
				.map(this::toDto)
				.orElseThrow(() -> new RuntimeException("Cliente no ha sido encontrado"));
	}

	@Override
	public ClientDto create(ClientDto clientDto) {
		// Create client
		Client client = fromDto(clientDto);
		return toDto(clientRepository.save(client));
	}

	@Override
	public ClientDto update(Long id, ClientDto clientDto) {
		// Update client
		Client existing = clientRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
		Client updated = fromDto(clientDto);
		updated.setId(existing.getId());
		return toDto(clientRepository.save(updated));
	}

	@Override
	public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
		// Partial update account
		Client client = clientRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
		if (partialClientDto.getPassword() != null)
			client.setPassword(partialClientDto.getPassword());

		client.setActive(partialClientDto.isActive());
		return toDto(clientRepository.save(client));
	}

	@Override
	public void deleteById(Long id) {
		// Delete client
		clientRepository.deleteById(id);
	}

	private ClientDto toDto(Client client) {

		ClientDto dto = new ClientDto();
		dto.setId(client.getId());
		dto.setName(client.getName());
		dto.setDni(client.getDni());
		dto.setGender(client.getGender());
		dto.setAge(client.getAge());
		dto.setAddress(client.getAddress());
		dto.setPhone(client.getPhone());
		dto.setPassword(client.getPassword());
		dto.setActive(client.isActive());
		return dto;
	}

	private Client fromDto(ClientDto dto) {
		Client client = new Client();
		client.setName(dto.getName());
		client.setDni(dto.getDni());
		client.setGender(dto.getGender());
		client.setAge(dto.getAge());
		client.setAddress(dto.getAddress());
		client.setPhone(dto.getPhone());
		client.setPassword(dto.getPassword());
		client.setActive(dto.isActive());
		return client;
	}
}
