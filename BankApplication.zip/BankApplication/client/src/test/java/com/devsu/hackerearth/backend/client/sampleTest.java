package com.devsu.hackerearth.backend.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.devsu.hackerearth.backend.client.DtoSimulate.AccountDto;
import com.devsu.hackerearth.backend.client.DtoSimulate.TransactionDto;
import com.devsu.hackerearth.backend.client.controller.ClientController;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.service.ClientService;

@SpringBootTest
public class sampleTest {

    private ClientService clientService = mock(ClientService.class);
    private ClientController clientController = new ClientController(clientService);

    @Test
    void createClientTest() {
        // Arrange
        ClientDto newClient = new ClientDto(1L, "0928522754", "Eduardo", "123456", "Male", 34, "Quito", "0980010976",
                true);
        ClientDto createdClient = new ClientDto(1L, "0928522754", "Eduardo", "123456", "Male", 34, "Quito",
                "0980010976", true);
        when(clientService.create(newClient)).thenReturn(createdClient);

        // Act
        ResponseEntity<ClientDto> response = clientController.create(newClient);

        // Assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(createdClient, response.getBody());
    }

    @Test
    void IntegrationFlowSimulationTest() {

        // Esto es solo una somulación del flujo simulada, no realiza persistencia. La
        // prueba de servicios está en postman y se comprueba la persistencia.
        
        // Paso 1 crear cliente
        ClientDto client = new ClientDto(1L, "0928522754", "Eduardo", "secret", "M", 34, "Quito", "0980010976", true);
        assertTrue(client.isActive());

        // Paso 2 CREAR CUENTA
        AccountDto account = new AccountDto();
        account.setId(1L);
        account.setClientId(client.getId());
        account.setNumber("123456789");
        account.setType("AHORRO");
        account.setInitialAmount(1000.00);
        account.setActive(true);

        assertEquals("123456789", account.getNumber());
        assertTrue(account.isActive());

        // Paso 3 REALIZAR TRANSACCIÓN
        double saldoActual = account.getInitialAmount();
        double monto = -200.00;
        double saldoEsperado = saldoActual + monto;

        TransactionDto tx = new TransactionDto();
        tx.setAccountId(account.getId());
        tx.setAmount(monto);
        tx.setDate(new Date());
        tx.setType(monto >= 0 ? "DEPOSITO" : "RETIRO");
        tx.setBalance(saldoEsperado);

        assertEquals("RETIRO", tx.getType());
        assertEquals(800.00, tx.getBalance());

    }
}
