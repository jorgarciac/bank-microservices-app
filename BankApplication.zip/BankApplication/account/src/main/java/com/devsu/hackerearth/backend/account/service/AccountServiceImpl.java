package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;

    public AccountServiceImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public List<AccountDto> getAll() {
        // Get all accounts
        return accountRepository.findAll().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public AccountDto getById(Long id) {
        // Get accounts by id
        return accountRepository.findById(id)
                .map(this::toDto).orElseThrow(() -> new RuntimeException("La cuenta no ha sido encontrada"));
    }

    @Override
    public AccountDto create(AccountDto accountDto) {
        // Create account
        Account entity = fromDto(accountDto);
        return toDto(accountRepository.save(entity));
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        // Partial update account
        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cuenta no encontrada"));
        if (partialAccountDto.getType() != null)
            account.setType(partialAccountDto.getType());

        account.setActive(partialAccountDto.isActive());
        return toDto(accountRepository.save(account));
    }

    @Override
    public void deleteById(Long id) {
        // Delete account
        accountRepository.deleteById(id);
    }

    @Override
    public AccountDto update(Long id, AccountDto accountDto) {
        Account existing = accountRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cuenta no encontrada"));
        Account updated = fromDto(accountDto);
        updated.setId(existing.getId());
        return toDto(accountRepository.save(updated));
    }

    private AccountDto toDto(Account account) {
        AccountDto dto = new AccountDto();
        dto.setId(account.getId());
        dto.setNumber(account.getNumber());
        dto.setType(account.getType());
        dto.setInitialAmount(account.getInitialAmount());
        dto.setActive(account.isActive());
        dto.setClientId(account.getClientId());

        return dto;
    }

    private Account fromDto(AccountDto dto) {
        Account account = new Account();
        account.setNumber(dto.getNumber());
        account.setType(dto.getType());
        account.setInitialAmount(dto.getInitialAmount());
        account.setActive(dto.isActive());
        account.setClientId(dto.getClientId());

        return account;
    }

}
