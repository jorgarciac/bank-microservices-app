package com.devsu.hackerearth.backend.account.service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;

    public TransactionServiceImpl(TransactionRepository transactionRepository, AccountRepository accountRepository) {
        this.transactionRepository = transactionRepository;
        this.accountRepository = accountRepository;
    }

    @Override
    public List<TransactionDto> getAll() {
        // Get all transactions
        return transactionRepository.findAll().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public TransactionDto getById(Long id) {
        // Get transactions by id
        return transactionRepository.findById(id)
                .map(this::toDto)
                .orElseThrow(() -> new RuntimeException("No se ha encontrado la transacción"));
    }

    @Override
    public TransactionDto create(TransactionDto transactionDto) {
        // Create transaction
        Account account = accountRepository.findById(transactionDto.getAccountId())
                .orElseThrow(() -> new RuntimeException("Cuenta no encontrada"));

        double cBalance = account.getInitialAmount();
        Transaction last = transactionRepository.findTopByAccountIdOrderByDateDesc(account.getId());
        if (last != null) {

            cBalance = last.getBalance();
        }

        double nBalance = cBalance + transactionDto.getAmount();
        if (nBalance < 0) {
            throw new RuntimeException("Saldo no disponible");

        }

        Transaction transaction = new Transaction();
        transaction.setAccountId(account.getId());
        transaction.setDate(new Date());
        transaction.setType(transactionDto.getAmount() >= 0 ? "DEPOSITO" : "RETIRO");
        transaction.setAmount(transactionDto.getAmount());
        transaction.setBalance(nBalance);
        return toDto(transactionRepository.save(transaction));
    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart,
            Date dateTransactionEnd) {
        // Report
        return accountRepository.findByClientId(clientId).stream().map(account -> {
            List<Transaction> txs = transactionRepository.findByAccountIdAndDate(
                    account.getId(), dateTransactionStart, dateTransactionEnd);
            List<TransactionDto> txDto = txs.stream().map(this::toDto).collect(Collectors.toList());

            Transaction last = transactionRepository.findTopByAccountIdOrderByDateDesc(account.getId());

            BankStatementDto dto = new BankStatementDto();
            dto.setAccountNumber(account.getNumber());
            dto.setAccountType(account.getType());
            dto.setActive(account.isActive());
            dto.setInitialAmount(last != null ? last.getBalance() : account.getInitialAmount());
            dto.setTransactions(txDto);
            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        // If you need it
        Transaction tx = transactionRepository.findTopByAccountIdOrderByDateDesc(accountId);
        if (tx == null)
            throw new RuntimeException("No existen transacciones");
        return toDto(tx);
    }

    private TransactionDto toDto(Transaction tx) {
        TransactionDto dto = new TransactionDto();
        dto.setId(tx.getId());
        dto.setAccountId(tx.getAccountId());
        dto.setDate(tx.getDate());
        dto.setType(tx.getType());
        dto.setAmount(tx.getAmount());
        dto.setBalance(tx.getBalance());

        return dto;

    }
}
